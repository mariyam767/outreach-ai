# Target List — Real Instagram Agents (verified via search, Sept 2026)

**Rule:** Din mein 10 DM se zyada nahi. Har DM mein unke profile se **ek specific
cheez** zaroor likho (hook column se). Copy-paste + hook = reply.

Chhote accounts pehle — wo reply karte hain. 100K+ accounts mein time waste
mat karo abhi.

---

## Tier 1 — Chhote, local, reply ke chances sabse zyada

| # | Handle | Naam / Market | Followers | Hook (DM mein use karo) |
|---|---|---|---|---|
| 1 | @listitwith_lauren | Lauren Williams — Dallas/North Texas | ~625 | "Turning houses into dream homes" wali line |
| 2 | @calvinstrainrealestate | Calvin — Dallas | ~408 | Trust The Beard + girl dad x4 (DM ready hai) |
| 3 | @homesbyashton_ | Ashton Thibodeaux — Houston TX | chhota | New homeowners ke saath celebration posts |
| 4 | @realtormckinsey | McKinsey Tutor — Austin TX | chhota | Listings + personal life ka mix |
| 5 | @realestate_atx | Austin local brand | chhota | Neighborhood-first content |

## Tier 2 — Mid-size, active, local experts

| # | Handle | Naam / Market | Followers | Hook |
|---|---|---|---|---|
| 6 | @shawnamartinez_realtor | Shawna Martinez — DFW | ~11K | New construction + listing expert, roz post karti hain |
| 7 | @buffalorealestatelady | Kim Santana — Buffalo NY | mid | Khud ke memes banati hain — humor ka angle |
| 8 | @derrickswflrealtor | Derrick Gregory — Southwest FL | mid | Local market content |
| 9 | @movemetotennessee | Marie Lee — Tennessee | mid | Relocation specialist — follow-up ka classic pain |
| 10 | @agentgila | Gila Goodman — Las Vegas | mid | "Here's what you get for $X" house tours |
| 11 | @j0rdanpatterson | Jordon Patterson — Nashville | mid | Sneakers + motivation + listings |
| 12 | @yourfriendlyneighborhoodmoose | Aken Moose Musa | mid | Friendly-neighbourhood branding |

## Tier 3 — Bade (abhi skip karo, baad mein)

@andreareynolds_thefitagent (29K), @rigoguzmann (297K), @iamlestacks (252K)
— inke inbox bharay hue hain. Pehli sales ke baad try karna.

---

## Ready DMs

### Lauren (@listitwith_lauren)

> Hey Lauren — found you through Dallas realtor tags, and "turning houses into
> dream homes" is exactly the kind of branding that made me stop.
>
> Quick question, not a pitch: with buyers and sellers across North Texas,
> how do you handle the leads that go quiet after the first conversation?
> Manual follow-up or something automated?
>
> I'm building a small tool for exactly this and asking agents before I build
> the wrong thing. Honest "not a problem" is a useful answer too.

### Ashton (@homesbyashton_)

> Hey Ashton — came across your page and love that you celebrate every new
> homeowner publicly, that's how you build a referral machine.
>
> Quick question, not a pitch: what happens to the leads who toured a home
> with you but went quiet? Do they get a follow-up sequence or do they slip?
>
> I'm building a small tool that writes those follow-ups for agents and asking
> realtors whether it's a real pain first. Honest answer either way helps.

### Shawna (@shawnamartinez_realtor)

> Hey Shawna — 100+ homes a year in the toughest market in a decade is
> genuinely impressive, saw your post about it.
>
> One question, not a pitch: at that volume, how do old leads get handled?
> You can't personally chase 400 of them between listings.
>
> I'm building a tool that writes the follow-up sequence for agents — asking
> top producers first whether it solves something real.

---

## Kal ke liye naye agents khud dhundne ka 2-minute formula

Instagram search mein ye likho aur **1K–15K followers** wale chuno:
- `#[city]realtor` (e.g. #phoenixrealtor, #atlantarealtor)
- `#[city]realestateagent`
- "real estate agent [city]"

Profile khol ke dekho: bio mein market likha ho, recent posts hon = zinda agent.

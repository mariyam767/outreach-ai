# Validation Outreach Pack — Real Estate Niche

**Maqsad:** 7 din mein 50 logon se baat karna. 3 log "haan main pay karunga"
kahein to niche pakki. Nahi to niche badlo, app nahi.

**Cost: $0. Sirf time.**

---

## ⚠️ Pehle 3 rules

1. **Bilkul same message 50 logon ko mat bhejo.** Har message mein unke baare
   mein ek specific cheez zaroor ho — unki listing, unka post, unka office area.
   Warna spam folder + account ban.
2. **Roz 20 se zyada naye messages mat bhejo** (LinkedIn pe to 15 se kam).
   Naya account limit pe jaldi flag hota hai.
3. **Pehle message mein kuch mat becho.** Sirf sawaal pucho. Sale teesre
   message pe aati hai, pehle nahi.

---

## Niche: US Real Estate Agents — kyun

- **Pain obvious:** har agent ke paas sैकड़ों purane leads hain CRM mein, follow-up
  karne ka time nahi. Deal chup-chaap mar jati hai.
- **Paisa pehle se kharch karte hain:** Zillow ads, CRM, coach — tools khareedna
  unki aadat hai.
- **Dhundna asaan:** Facebook groups, Instagram, LinkedIn, Zillow profiles — sab public.
- **English market:** aap product English mein bana rahe ho, buyers bhi English.

**Backup niches** (agar ye na chale): insurance agents, recruiters, med spas,
HVAC/plumbing contractors.

---

# 1. Facebook Groups (sabse asaan, sabse fast)

**Groups dhundo:** Facebook pe search karo —
- "Real Estate Agents USA"
- "Real Estate Lead Generation"
- "Realtor Mastermind"
- "[City name] Real Estate Agents" (e.g. "Dallas Real Estate Agents")

Join 5–8 groups. **Pehle 2 din sirf dusron ke posts pe helpful comment karo** —
seedha pitch mat karo, warna admin remove kar dega.

### Post #1 — sawaal wala (sabse best performer)

> Quick question for the agents here —
>
> How many leads are sitting in your CRM right now that you haven't touched in
> over 90 days?
>
> Genuinely curious. I'm building something for exactly that problem and I want
> to know if I'm solving a real problem or one I made up in my head.
>
> Not selling anything yet. Just want honest answers.

**Kyun chalta hai:** Sawaal hai, pitch nahi. Log apni problem batane mein maza
lete hain. Har comment = ek warm lead.

### Post #2 — problem-first

> Agents — what's the one follow-up task you keep meaning to automate but never do?
>
> Building a small tool and picking what to build first based on answers here.
> First 5 people who reply get free access for life when it's ready.

### Post #3 — build-in-public

> Day 3 of building a cold-email tool for real estate agents.
>
> Wrote the logic that keeps emails under 80 words and bans every phrase that
> sounds like AI wrote it ("hope this finds you well", "just checking in").
>
> Agents — what other phrases make you instantly delete an email?
> Genuinely collecting a blacklist.

---

# 2. Instagram DMs (real estate agents yahan sabse active hain)

**Kaise dhundo:** Instagram pe `#realestateagent` `#[city]realtor` search karo.
Ya Zillow pe agent ka profile → unka Instagram link.

### DM #1 (pehla message — sirf sawaal)

> Hey [Name] — came across your page through [city] real estate tags.
>
> Random question, not a pitch: how do you currently handle the leads in your
> CRM that have gone quiet? Manual follow-up or something automated?
>
> Building a small tool for this and asking agents before I build the wrong thing.

### DM #2 (agar reply aaye)

> That's helpful, thank you.
>
> So the tool writes the whole follow-up sequence for you — you paste one lead's
> details, it writes 3 emails + a LinkedIn message that don't sound like AI wrote them.
>
> Would something like that save you real time, or is this not actually a pain
> for you? Honest answer is fine either way.

### DM #3 (agar wo "yes useful" kahe)

> Okay — would you pay for it?
>
> Thinking $49 one time, no subscription. I'll give the first 5 people free
> access + lifetime updates in exchange for a testimonial and blunt feedback.
>
> Want me to send you the link when it's live?

---

# 3. LinkedIn (thoda slow, lekin brokers yahan hain)

**Kaise dhundo:** LinkedIn search — "Real Estate Broker" + [city]. Ya
"Realtor" filter.

### Connection request (300 char limit)

> Hi [Name] — I work with real estate agents on lead follow-up. Not pitching,
> just trying to learn whether a tool I'm building solves a real problem for
> brokers in [city]. Would be useful to connect.

### Message after they accept

> Thanks for connecting, [Name].
>
> One question, then I'll leave you alone: how many untouched leads are sitting
> in your CRM right now?
>
> I'm building a tool that writes the follow-up emails for you (3-email
> sequence + LinkedIn, from one lead's details). Before I build more of it I'm
> asking 50 agents whether this is a real pain or one I invented.
>
> Honest "not a problem for me" is a genuinely useful answer.

---

# 4. Reddit

**Subreddits:** r/realtors, r/RealEstate, r/realestateinvesting

⚠️ Reddit pe self-promotion jaldi remove hoti hai. **Pehle 1 hafte sirf answers
do, koi link mat do.**

### Post (text only, koi link nahi)

> Agents: how much of your pipeline is leads older than 6 months that you've
> stopped contacting?
>
> I keep seeing agents say they "need better lead gen" but then I look at their
> CRM and they have 400+ contacts they haven't touched. Curious whether that's
> actually common or whether I'm over-indexing on a few people I've talked to.

---

# 5. Objection handlers (jab wo ye kahein)

**"I already have a CRM that does this."**
> Most do — and most of those built-in drip campaigns get ignored because
> they're generic. This writes each email from that one lead's details, so it
> reads like you typed it. Different job.

**"$49 is too much." / "Can I get it free?"**
> Totally fair. The first 5 people get it free for a testimonial and honest
> feedback. After that it's $49 because every email costs me AI credits.
> Want one of the 5 free spots?

**"Send me more info."**
> It's a one-page tool, no demo needed — you paste a lead's details and get
> three emails in about 10 seconds. Here's what it wrote for a fake agent
> this morning: [paste one generated email]

**"Is this AI spam?"**
> It's the opposite, honestly. The whole point is it refuses to write the
> phrases that get emails deleted — no "hope this finds you well", no
> "just checking in", under 80 words, one question per email.

**No reply after 4 days** (ek hi follow-up, phir chhod do):
> Hey [Name] — closing the loop so I'm not cluttering your inbox. If old-lead
> follow-up isn't a pain for you, no worries at all. If it comes up later,
> happy to send the tool over.

---

# 6. Aapka 7-din ka plan

| Din | Kaam | Target |
|---|---|---|
| **1** | Groq key + Payoneer + Paddle/Polar applications. 5–8 FB groups join karo | Setup done |
| **2** | Groups mein sirf helpful comments (koi pitch nahi). 10 IG accounts shortlist | 0 pitches |
| **3** | FB Post #1 lagao. 10 IG DMs bhejo | 10 messages |
| **4** | 10 IG DMs + 5 LinkedIn requests | 15 messages |
| **5** | Jo reply aaye unse DM #2 bhejo. 10 naye DMs | 25 total |
| **6** | Reddit post. 10 LinkedIn messages. Follow-ups | 40 total |
| **7** | Baaki 10. Sab replies ko DM #3 bhejo. **Count karo** | **50 total** |

**Tracker:** `validation-tracker.xlsx` — har message log karo, reply rate dekho.

---

# 7. Decision gate (din 7 pe)

50 messages ke baad:

| Result | Kya karna hai |
|---|---|
| **3+ log** "haan pay karunga" | ✅ Niche pakki. Deploy karo, pehle 5 free customers lo |
| **1–2 log** interested, zyada replies | 🟡 Pricing ya messaging tweak karo, 50 aur bhejo |
| **Bohot replies, koi pay nahi karega** | 🟠 Problem real hai lekin tool nahi chahiye — offer badlo |
| **50 mein se 2–3 replies** | 🔴 Niche ya channel galat. Backup niche try karo |

**Sabse badi galti:** 50 messages bhejne se pehle product perfect banane mein
3 mahine laga dena. Ye 50 messages $0 ke hain aur aapko 3 mahine bachate hain.

---

# 8. Tracker kaise use karein

`validation-tracker.xlsx` kholein:
- **Outreach** sheet: har message ka naam, platform, date, status
- **Summary** sheet: reply rate aur "would pay" count **automatic** calculate hota hai
- **Script** sheet: saare message templates ek jagah, copy-paste ke liye

Status dropdown mein: `Sent` / `Replied` / `Interested` / **`Would pay`** / `No`

**Sirf "Would pay" column matter karta hai.** Baaki sab noise hai.

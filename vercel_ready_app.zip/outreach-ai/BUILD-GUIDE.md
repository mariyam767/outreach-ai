# OutreachAI — Step by Step Build Guide

Ye guide batata hai ke app **kaise bani** aur **aapko ab kya karna hai**.
Har line number actual file se verify kiya gaya hai (Sept 13, 2026).

App already bani hui hai: `~/outreach-ai`. Ye guide do hisson mein hai —
**Part A**: architecture samjho. **Part B**: khud customize + launch karo.

---

# PART A — App kaise kaam karti hai

## Request ka poora safar

```
User form bharta hai (app/page.tsx)
        ↓  POST /api/generate  (JSON)
Validation + size caps (app/api/generate/route.ts)
        ↓  GenerateInput object
generateOutreach() (lib/ai.ts)
        ↓
   MOCK_AI=1 hai?  ──haan──→  built-in writer (lib/fallback.ts)
        ↓ nahi
buildPrompt() (lib/prompt.ts)  →  system + user prompt
        ↓
Groq → fail? → Gemini → fail? → Mistral → fail? → OpenRouter
        ↓  raw text (aksar JSON, kabhi markdown mein wrapped)
extractJson() + normaliseResult() (lib/prompt.ts)
        ↓
Sab fail? ──→ built-in writer (lib/fallback.ts)
        ↓
{ ok, result, mock }  →  UI tabs mein dikhta hai
```

**Sabse zaroori baat:** har jagah fallback hai. Free tier quota khatam ho jaye,
network down ho, ya model garbage lote — user ko error nahi, output milta hai.

---

## File by file — kya kahan hai

| File | Lines | Kaam |
|---|---|---|
| `lib/prompt.ts` | 131 | **Asli product.** 11 writing rules + JSON repair |
| `lib/ai.ts` | 201 | 4 providers, fallback chain, 45s timeout |
| `lib/fallback.ts` | 274 | $0 deterministic writer + text normalisation |
| `app/page.tsx` | 555 | UI, free counter, paywall |
| `app/api/generate/route.ts` | 70 | Validation, size caps |
| `lib/types.ts` | 68 | Shared types + constants |

---

## Step 1 — Data shape pehle decide karo (`lib/types.ts`)

Code likhne se pehle ye tay kiya: **input kya hoga, output kya hoga.**

```ts
export type GenerateInput = {
  yourCompany, yourOffer, yourName,        // aapka offer (ek baar bharta hai)
  industry, industrySingular, painPoint,   // aapka target
  prospectName, prospectRole, prospectCompany, personalNote,  // ek prospect
  goal, tone
}

export type OutreachResult = {
  emails: [{ subject, preheader, body, sendAfterDays }]   // 3 emails
  linkedin: { connectionRequest, followUp }
  icebreakers: string[]
  provider: string    // kaunsa model ne likha — debug ke liye
}
```

**Kyun pehle:** Agar ye clear na ho to prompt aur UI dono idhar udhar bhatakte
hain. Ye 68 lines poore project ka contract hain.

`industrySingular` baad mein add karna pada — kyunki built-in writer ko
"real estate agent" ko plural karna tha aur "agentss" ban raha tha.

---

## Step 2 — Product likho, code nahi (`lib/prompt.ts`)

Ye file hi product hai. Baaki sab plumbing hai.

**11 rules jo output ko generic ChatGPT se alag banate hain** (lines 14–24):

| # | Rule | Kyun |
|---|---|---|
| 1 | Body 80 words se kam | Lambi cold email delete ho jati hai |
| 2 | Pehli line prospect ke baare mein, sender ke baare mein nahi | "I hope this finds you well" = instant delete |
| 3 | Ek CTA, soft (interest-based, time-based nahi) | "Worth a look?" > "Tuesday 2pm free ho?" |
| 4 | **Banned words list** — leverage, synergy, unlock, elevate, "quick question"… | Ye words AI ka fingerprint hain |
| 5 | Koi exclamation mark, max ek question mark | Over-eager lagta hai |
| 6 | Aisa lage phone pe type hua hai | Marketing formatting = spam folder |
| 7 | Brief ke real specifics use karo | Vague = reply nahi |
| 8 | **Statistics/client names invent mat karo** | Jhootha proof = customer ki reputation khatam |
| 9 | Teeno emails alag angles: pain → proof → breakup | Ek hi email 3 baar = ignore |
| 10 | LinkedIn request 300 characters se kam | LinkedIn ka hard limit |
| 11 | Brief ki language mein likho, translate mat karo | |

**Rule 8 sabse important hai.** Ek AI tool jo customer ke liye jhootha result
invent kar de, wo ek hi din mein refund + bad review deta hai.

**JSON output:** model ko exact shape diya (line 48). Lekin models aksar
` ```json ` fences laga dete hain, isliye `extractJson()` (line 63) teen
tareeqe try karta hai: direct parse → fence unwrap → outermost braces.

`normaliseResult()` (line 96) defensive hai: bina body wali emails drop,
LinkedIn ko 300 pe clip, icebreakers filter.

---

## Step 3 — Providers + fallback chain (`lib/ai.ts`)

```ts
const providers = [Groq, Gemini, Mistral, OpenRouter].filter(p => p.key)
for (const p of providers) {
  try { return normaliseResult(extractJson(await p.call()), p.name) }
  catch (e) { errors.push(...) }
}
return generateFallback(input)   // sab fail → phir bhi output
```

**Order kyun aisa hai:** Groq pehle kyunki wo **data pe training nahi karta**.
B2B customer ke liye ye matter karta hai — Gemini free tier pe Google aapka data
training mein use kar sakta hai.

Har call pe **45 second timeout** (`AbortController`), warna free tier ka slow
response user ko forever loading pe bitha deta.

**`MOCK_AI` server-side hai, `NEXT_PUBLIC_` nahi.** Ye ek asli bug tha jo test
se pakda gaya: `NEXT_PUBLIC_*` variables Next.js build-time pe client bundle
mein inline kar deta hai. Matlab ek baar flag ke saath build kiya to production
build **hamesha** demo mode mein rehta, runtime env kuch bhi ho.

---

## Step 4 — $0 fallback writer (`lib/fallback.ts`)

Do kaam: (a) sab providers fail ho jayein to bhi output, (b) bina key ke demo.

**Is file mein sabse zyada bugs mile** — kyunki user short fields mein poori
sentences paste karta hai ("They have 400 leads in their CRM and no time to
follow up."). Har field ko us sentence slot ke grammatical shape mein convert
karna padta hai:

| Helper | Kaam |
|---|---|
| `clean()` | Whitespace collapse, trailing punctuation strip |
| `deCap()` | "They have…" → "they have…", lekin "Miller Realty" aur "CRM hygiene" ko chhede nahi |
| `pluralize()` | "agent" → "agents", "agents" → "agents" (double s nahi) |
| `topicPhrase()` | Poori sentence → noun phrase: "the 400 leads in your CRM" |
| `offerClause()` | "We run X" → sentence subject banane layak clause |

Ye sab helpers **exported** hain aur `test/unit.test.ts` mein pinned hain.

---

## Step 5 — API route: validation (`app/api/generate/route.ts`)

- `clean(value, max)` — har field pe hard character cap. Free tier quota chhoti
  hai, ek request bhaag na jaye.
- **Minimum brief rule:** `yourOffer` ya `painPoint` 10 characters se kam ho to
  **422** return karta hai. Kyun? Kyunki vague brief = vague email = user sochta
  hai "ye tool bekaar hai" = churn. Ye guard deliberately hai.
- `goal`/`tone` whitelist se validate hote hain, warna default.

---

## Step 6 — UI (`app/page.tsx`)

- **Free counter:** `localStorage`, 3 generations (`FREE_GENERATIONS` in
  `lib/types.ts:68`). 3 ke baad paywall overlay.
- **Copy button:** `navigator.clipboard` try karta hai, fail ho to
  `execCommand` fallback — kyunki sandboxed iframe mein async clipboard block
  hota hai.
- **Word count** har email ke neeche — user ko dikhta hai ke 80-word rule follow
  hua ya nahi.
- **Mock banner:** API `mock` flag bhejta hai, UI warning dikhata hai.

---

# PART B — Ab aapko kya karna hai

## Step 7 — Validation (code se pehle, 2–4 din, $0)

**Ye skip mat karna.** App ban gayi hai, lekin niche galat hui to sab bekar.

1. Ek niche chuno (real estate agents / recruiters / agencies / dentists).
2. Us niche ke 3 Facebook groups + 2 subreddits join karo.
3. **50 personalized messages** bhejo. Script:

> Hi [Name] — [unke baare mein ek specific cheez].
> Main ek tool bana raha hoon jo [niche] ke liye cold email sequences likhta hai —
> 3 emails + LinkedIn message, ek prospect ki details se.
> Aap abhi cold outreach karte ho? Agar haan, to sabse zyada time kis cheez mein
> lagta hai?
> (Kuch bech nahi raha, sirf ye check kar raha hoon ke tool banane layak hai ya nahi.)

4. **Gate:** kam az kam **3 log** kahein "haan main iske liye pay karunga."
   Nahi → niche badlo, product nahi. Cost = $0, aur 3 hafte bach gaye.

---

## Step 8 — Niche ke hisaab se customize karo (30 min)

Sirf **2 files** badalni hain:

### `app/page.tsx`

| Line | Kya badalna hai |
|---|---|
| **17** | `HEADCOUNT_COPY` — naam + headline. Headline mein **niche ka naam ho**: "Cold emails for real estate agents" > "AI email writer" |
| **27–28** | `PRICE` / `PRICE_NOTE` |
| **41** | `DEFAULTS.industry` — aapki niche |
| placeholders | Har input ka `placeholder` text apni niche ka example |

### `lib/types.ts`

| Line | Kya |
|---|---|
| **68** | `FREE_GENERATIONS = 3` — kam rakho, warna free users poori quota kha jayenge |

**Price $19 se neeche mat jao.** Har generation ka AI cost aap uthate ho.

---

## Step 9 — Free AI key lagao (10 min, $0)

```bash
cd ~/outreach-ai
cp .env.example .env.local
```

`.env.local` mein **ek** key daalo:

```
GROQ_API_KEY=gsk_...
```

- **Groq** (recommended): https://console.groq.com/keys — ~1,000 req/day free,
  **data pe training nahi karta**
- Gemini: https://aistudio.google.com/apikey — 1,500 req/day, ⚠️ free tier pe
  Google data training mein use kar sakta hai
- Mistral: https://console.mistral.ai/api-keys — ~1B tokens/month
- OpenRouter: https://openrouter.ai/keys — 50 req/day

Chaaron `.env.example` mein documented hain. **Koi card nahi maangta.**

Test:
```bash
npm run dev
# http://localhost:3000 — form bharo, "Generated by Groq / llama-3.3-70b" aana chahiye
```

Agar "sample" likha aaye to key nahi lagi — banner bhi yehi kahega.

---

## Step 10 — Deploy karo (20 min, $0)

1. GitHub pe naya repo banao, `outreach-ai` folder push karo
   (`.gitignore` already `node_modules`, `.next`, `.env.local` exclude karta hai)
2. vercel.com → **Add New Project** → repo import
3. Framework auto-detect ho jayega (Next.js). Build settings chhedo mat.
4. **Settings → Environment Variables** → `GROQ_API_KEY` add karo
5. Deploy → free `yourapp.vercel.app` URL

`next.config.mjs` mein `images.unoptimized` already set hai, isliye koi paid
image service nahi chahiye.

---

## Step 11 — Payments connect karo ($0/month)

Stripe Pakistan mein directly nahi chalta. **Merchant of Record** use karo.

| Provider | Fee | Monthly | PK payout |
|---|---|---|---|
| **Paddle** | 5% + $0.50 | **$0** | Payoneer / wire |
| **Polar** | 4% + $0.40 | **$0** | Stripe Connect Express |
| Dodo Payments | 3% + $0.50 | **$0** | signup pe check |
| Fungies.io | 5% + $0.50 | **$0** | signup pe check |
| Lemon Squeezy | 5% + $0.50 +1.5% intl | **$0** | wire |

**Aaj hi 2 kaam** (approval mein hafte lagte hain):
1. **Payoneer** account kholo (free, Pakistan supported)
2. **Paddle + Polar dono pe apply** karo

⚠️ Application mein **clearly** likho: payment ke baad user ko turant kya milta
hai + screenshots. Vague application = rejection — solo founders ke saath sabse
zyada yehi hota hai.

⚠️ **Polar ka catch:** Stripe Connect us country ka **local-currency bank
account** maangta hai. Wise/Payoneer multi-currency account aksar reject hota
hai. Signup pe apna PKR account test karo. Paddle ka Payoneer route zyada direct hai.

Phir checkout link `app/page.tsx:26` ke `CHECKOUT_URL` mein daalo.

---

## Step 12 — Pehle 5 customers ($0 marketing)

1. **Roz 20 personalized messages** — LinkedIn + FB groups + niche subreddits
2. **Chrome extension** — apne Chrome pe "Load unpacked" se bilkul free test karo.
   Store pe publish karne ke liye $5 one-time fee hai — **wo pehli sale ke baad** dena, pehle nahi.
   Zero-budget ka sabse underrated channel.
3. Niche communities mein **genuinely helpful posts** (spam nahi). Ek achha post
   = 50 signups.
4. **5 founding customers ko 50% off** do, testimonials lo (screenshot + chhota video)
5. **SEO pages**: "cold email examples for real estate agents" + 20 variations.
   3–6 mahine mein compounding free traffic.
6. **Affiliates 30–40%** — koi upfront paisa nahi
7. **AppSumo abhi NAHI** — Marketplace deal pe 70% commission lete hain, aur
   ~40% products 3 saal mein band ho jate hain. 50+ customers ke baad socho,
   aur tab Select plan (30%) pe jao.

---

## Tests chalana

```bash
npm test                 # unit + integration (28 tests)
npm run test:unit        # sirf text helpers + generated copy

# integration ke liye app chahiye, provider mode mein:
GROQ_API_KEY=test GROQ_BASE_URL=http://127.0.0.1:4010/v1 npm run start
npm run test:integration
```

Integration test ek **fake Groq server** boot karta hai aur real adapter ko us pe
point karta hai — matlab prompt, JSON parsing, quota fallback sab asli code path
se guzarta hai, bina API key ke.

Agar aap `MOCK_AI=1` pe app chala ke integration test chalao to test **clear
error** dega ke "app mock mode mein hai, provider key ke saath restart karo" —
confusing failures ke bajaye.

---

## Jo maine check NAHI kiya

- **Asli Groq API pe live call** — mere paas key nahi thi, isliye maine fake
  server se poori chain verify ki. Pehli baar apni key laga ke khud ek generation
  chalana aur output quality dekhna.
- **Paddle/Polar approval** — ye aapki application pe depend karta hai.
- **Actual sales** — koi guarantee nahi. Median micro-SaaS $145 MRR kamata hai
  aur ~70% kabhi $1,000 cross nahi karte. Distribution pe jeet hoti hai, code pe nahi.

---

## Summary — kitna time lagega

| Step | Time | Kharcha |
|---|---|---|
| 7. Validation (50 messages) | 2–4 din | $0 |
| 8. Niche customize | 30 min | $0 |
| 9. AI key | 10 min | $0 |
| 10. Deploy | 20 min | $0 |
| 11. Payments | 1 hafte (approval wait) | $0 |
| 12. Pehle 5 customers | 2–4 hafte | $0 |

**Total: ~1 mahina, $0.** Sirf aapka time.

# Content Calendar — 14 din, roz 1 post (1 minute/day)

**Jawab aapke sawaal ka:** rozana content **dhundna nahi** parta — ye folder
mein pehle se hai. `outreach-ai/ig/` mein 14 branded cards hain
(post-01 se post-14). Roz sirf:

1. Calendar mein dekho aaj kaunsa post hai
2. Image upload karo + caption copy karo
3. 2 hashtag lines paste karo

**Bas.** Naya content tab banega jab ye khatam ho — `make_batch.py` mein naye
stats daal ke dobara chalao, 1 minute mein 12 naye cards.

---

## Hafta 1

| Din | File | Caption (copy-paste) |
|---|---|---|
| 1 | post-01.png | 48% of real estate leads never get a follow-up. Meanwhile 78% of buyers go with the first agent who responds. The gap between those numbers is your commission. #realestateagent #realtorlife #leadgeneration |
| 2 | post-02.png | You already paid $20-$150 for each of those leads. Every one sitting untouched is money going quiet. Turn them back into conversations. #realestate #realtor #crm |
| 3 | post-03.png | 5 minutes. That's the window. Leads contacted within 5 minutes are 21x more likely to qualify. After 30 minutes? Gone. #realestatetips #realtorlife #followup |
| 4 | post-04.png | 78% of buyers work with the first agent who responds. Not the best agent. The FIRST. Speed beats credentials every single time. #realestateagent #buyersagent #realtor |
| 5 | post-05.png | The average agent takes 15+ hours to answer a web lead. If you answer in 5 minutes, you're already ahead of 90% of your market. #realestateleads #realtorlife |
| 6 | post-07.png | Portal leads close at 0.4-1.2%. Sounds bad — until you realize follow-up is what separates the 1% from the 0.4%. #leadgeneration #realestatetips |
| 7 | **VIDEO** | Screen recording demo (neeche script V1). Caption: "POV: a lead went quiet 3 months ago. Watch what 10 seconds fixes. #realestate #ai #realtorlife" |

## Hafta 2

| Din | File | Caption |
|---|---|---|
| 8 | post-06.png | 5 touches in 10 days converts 40% of the leads who never replied. The money isn't in new leads. It's in the ones you already have. #realestateagent #crm #followup |
| 9 | post-08.png | The median agent spends $8,010 a year on marketing. Half of it dies in the follow-up gap. Fix the gap first. #realestatemarketing #realtor |
| 10 | post-09.png | 67% of homebuyers now start their search with an AI tool. Up from 17% eighteen months ago. The market moved. Did you? #realestate #ai #realtorlife |
| 11 | post-10.png | Old leads are referrals you haven't made yet. Referrals close at 14-20% — better than any portal on earth. #realestatetips #referrals |
| 12 | post-11.png | CRM users convert 29-41% better. Keyword: users. A CRM you don't follow up in is a very expensive address book. #realtor #crm |
| 13 | post-14.png | One lead's details in. Three emails out. Ten seconds. That's the whole product. Link in bio. #realestateagent #ai #leadgeneration |
| 14 | **VIDEO** | Stats slideshow (script V2). Caption: "5 numbers every agent should tattoo on their desk. #realestatetips #realtorlife" |

---

## Video scripts (haftay mein 1, 30-45 second)

Aap motivation videos banate ho — ye usi skill ka use hai, bas topic badla hai.

### V1 — Screen demo (sabse powerful, chehra nahi chahiye)

1. Phone/PC pe screen recording on karo
2. App kholo → ek example lead bharo (Sarah Miller, Miller Realty, "just opened a second office in Plano")
3. Generate dabao → sequence dikhao → **Email 1 pe zoom**
4. Text overlay: "10 seconds. No AI-sounding junk."
5. End card: "RealtyReach — $49 lifetime. Link in bio."

### V2 — Stats slideshow (15-30 second)

1. post-03, post-04, post-06 cards ko slideshow mein daalo (Instagram ka built-in
   "select multiple" mode)
2. Trending audio lagao
3. Pehli slide pe text: "5 numbers that explain why deals die"

### V3 — (optional, jab confidence aaye) Talking head 20 sec

"Three reasons your leads die. One: you answer in 15 hours, they wanted 5 minutes. Two: you follow up once, it takes five. Three: your emails sound like a robot wrote them. Fix all three in ten seconds — link in bio."

---

## Naye cards chahiye to (1 minute)

`ig/make_batch.py` kholo → `CARDS` list mein naya stat likho →
`python3 make_batch.py` → naye cards ban jayengi.

Naye stats kahan se aate hain? Isi chat mein mujhse pucho ("ek aur stat do
follow-up ke baare mein") — main verified de dunga. Ya housingwire / NAR ki
reports se.

---

## Roz ka asal kaam (yaad rakho)

Post = **marketing**. DM = **sales**. Dono chahiye:
- Subah: 1 post (1 min)
- Shaam: 10 DMs (20 min)

Post se log aapko jaante hain; DM se paisa aata hai.

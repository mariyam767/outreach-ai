# Instagram Brand Account — 3-din ka setup

Aapka personal motivation page **alag rakho** — wo aapki personal brand hai,
usay mix mat karo. US agents ko DM ek **product account** se karo. Ye normal
startup practice hai, koi deception nahi: product ka apna page hota hai.

---

## Din 1 — Account banao (10 min)

1. Instagram → Settings → **Add account** → **Create new account**
2. Handle (jo available ho):
   - `@realtyreach.app`
   - `@realtyreach.ai`
   - `@realtyreach.hq`
3. Profile pic: **`ig/profile.png`** (workspace ke `outreach-ai/ig/` folder mein)
4. Name field: **RealtyReach — AI Follow-up for Agents**
5. Bio (copy-paste):

```
Follow-up emails for real estate agents, written by AI.
Paste one lead → get 3 emails + a LinkedIn message.
$49 lifetime. First 5 agents free.
```

6. **Post #1 lagao:** `ig/post-1.png` + ye caption:

```
48% of real estate leads never get a follow-up.

Meanwhile 78% of buyers work with the first agent who responds.

The gap between those two numbers is your commission.

RealtyReach writes the follow-up for you — 3 emails + a LinkedIn
message from one lead's details.

#realestateagent #realtorlife #realestatetips #leadgeneration
#dallasrealtor #realestateleads
```

7. **15 agents follow karo** (#dallasrealtor se) aur unki 8–10 posts like karo.
   DM abhi NAHI bhejna.

## Din 2 — Thoda zinda dikhao (10 min)

1. **Post #2 lagao:** `ig/post-2.png` + caption:

```
You already paid $20-$150 for each of those leads.

Every one sitting untouched in your CRM is money going quiet.

Turn them back into conversations — link in bio.

#realtor #realestate #crm #followup #realestateleads
```

2. 5 agents ki posts pe **genuine comments** karo (2–4 words kaam nahi aate;
   ek line likho, e.g. "That Oak Lawn staging looks sharp — great listing.")

## Din 3 — Pehle DMs (20 min)

Ab account "zinda" lagta hai: pic, 2 posts, activity. **Ab DM bhejo** —
Calvin se shuru karo (OUTREACH-PACK wala DM #1). Din mein **10 se zyada nahi**.

---

## Kyun ye zaroori hai

- Naya account + turant DM = Instagram **spam flag** kar deta hai. 2 din ka
  warm-up ye risk kam karta hai.
- Agent aapka profile dekhega to **product page** dikhega, motivation page nahi.
  Dono apni jagah theek hain — bas mix nahi karne.
- Bonus: aap motivation videos banati/banate ho, matlab **content banana aata
  hai**. Ye skill yahan kaam aayegi — haftay mein 2 card posts kaafi hain.

## Assets (workspace mein)

| File | Kya hai |
|---|---|
| `outreach-ai/ig/profile.png` | Profile picture (lime "R") |
| `outreach-ai/ig/post-1.png` | "48% never get a follow-up" card |
| `outreach-ai/ig/post-2.png` | "$20-$150 per lead" card |
| `outreach-ai/ig/make_cards.py` | Naye cards banane ka script — text badal ke chalao |

Nayi card chahiye to `make_cards.py` mein text badlo aur `python3 make_cards.py`
chalao — same brand style mein card ban jayegi.

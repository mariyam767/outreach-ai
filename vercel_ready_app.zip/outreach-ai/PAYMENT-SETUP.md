# Payment Setup — Aaj ka 45-minute kaam

App ready hai. Ab **paisa aane ka rasta** kholo. Ye teen kaam isi hafte karo —
approval mein din lagte hain, isliye jitni jaldi utna behtar.

---

## 1. Payoneer (10 min) — paisa receive karne ka account

1. https://www.payoneer.com → **Sign Up** → "Individual"
2. Naam bilkul wahi likho jo **CNIC** pe hai
3. Address + Pakistan ka **PKR bank account** (jo bhi hai, wahi)
4. Email verify karo. Approval 1–3 din mein aata hai.

Ye aapka "bridge" hai: Paddle/Polar → Payoneer → aapka PK bank.

---

## 2. Paddle application (15 min)

1. https://www.paddle.com → **Get started / Sign up**
2. Email se account banao
3. Onboarding mein product details maangega. **Neeche wala text copy-paste karo**
   aur `[YOUR APP URL]` ki jagah apna link dalo (Arena preview link chal jayega;
   baad mein Vercel wala):

```
Product name: RealtyReach

What it does:
RealtyReach is a web application for US real estate agents and brokers.
An agent pastes one lead's details (name, company, role, one personal note)
and the app instantly generates a 3-email follow-up sequence, a LinkedIn
connection request, and a follow-up message, written by an AI model.

Pricing: $49 one-time payment for lifetime access. No subscription.

What the buyer receives immediately after paying:
Unlimited sequence generation is unlocked on the same page, instantly.
There is no manual fulfilment, no shipping, nothing sent later — the
software access activates at the moment of payment.

Target customers: Real estate agents and brokers, primarily in the US.

Seller: Individual seller based in Pakistan. Payouts to be received via
Payoneer.

Live product URL: [YOUR APP URL]
```

4. **2 screenshots attach karo:** (a) home page, (b) generated result page.
   Screenshot lene ke liye apni preview kholo aur keyboard se `PrtScn` ya
   Windows Snipping Tool use karo.

---

## 3. Polar application (10 min) — backup + sasta (4% + $0.40)

1. https://polar.sh → **Sign up** (GitHub ya email se)
2. Organization/product banao, wahi description paste karo (upar wala text)
3. Payout account connect karo — **Stripe Connect Express** khulega,
   country **Pakistan** chuno.
   ⚠️ Ye aapka **local PKR bank account** maangta hai. Wise/Payoneer ka
   multi-currency account yahan aksar **reject** hota hai — apna asli PK
   account use karo. Agar reject ho to ghabrana mat: **Paddle (Payoneer
   route)** primary hai, Polar backup.

---

## 4. Approval ke baad (2 min)

Jo checkout link mile (Paddle checkout URL ya Polar checkout link), wo
`app/page.tsx` mein **line 26** pe `CHECKOUT_URL` mein paste karo:

```ts
const CHECKOUT_URL = "https://your-checkout-link";
```

Bas. "Get lifetime access" button ab paisa lega.

(Mujhe link bhej do to main laga dunga.)

---

## Agar reject ho jaye (common hai, give up mat karna)

Reject email ka **reply** karo aur ye likho:

```
Thanks for reviewing. To clarify the purchase flow: the buyer pays on the
checkout page and immediately receives unlimited access to the software on
the same page — credits are added to their account instantly after payment.
There is no delayed or manual fulfilment.

I have attached screenshots of (1) the product page and (2) the output the
buyer receives after paying.

Could you let me know if any specific detail is missing from my application?
```

+ screenshots dobara attach karo. Bahut se founders doosri try mein pass ho jate hain.

---

## Order of priority

1. **Payoneer** — pehle, kyunki dono providers isi se pay karte hain
2. **Paddle** — primary (Payoneer payout direct)
3. **Polar** — backup

Ye teeno **$0/month** hain. Sirf per-sale commission kat-ta hai.

**Jab ye chal rahe hon, agla kaam:** 50 outreach messages
(`OUTREACH-PACK.md`) — kyunki payment link tab hi kaam aata hai jab koi
khareedne wala ho.
